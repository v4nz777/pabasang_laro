Card({
    onCreate: function () {
        var self = this;
        var screenSize = ApApi.getScreenSize();
        this.$data.widthDp = screenSize.widthDp;
        // 根据span对应用进行分组
        this.groupItems();
    },
    groupItems: function () {
        console.log("data = " + JSON.stringify(this.$data))
        var span = this.$data.config.span;
        if (!span) {
            span = 3;
            this.$data.config.span = 3;
        }
        var list = this.$data.data;
        var groupCount = (list.length % span) === 0 ? list.length / span : (list.length / span + 1);
        groupCount = Math.floor(groupCount)
        var groups = [];
        for (let i = 0; i < groupCount; i++) {
            var subList = [];
            for (let j = 0; j < span; j++) {
                var index = i * span + j;
                if (index >= list.length) {
                    break
                }
                subList.push(list[i * span + j]);
            }
            groups.push(subList);
        }
        this.$data.groups = groups;
    }
})